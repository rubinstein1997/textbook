package edu.wxc.book.domain;

public class auditor {
    private Integer id;

    private String name;

    private String passwd;

    private String college;

    private Long telephone;
}
